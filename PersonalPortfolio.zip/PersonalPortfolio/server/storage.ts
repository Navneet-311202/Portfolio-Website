import { 
  messages, projects, skills, experiences, education,
  type Message, type InsertMessage,
  type Project, type InsertProject,
  type Skill, type InsertSkill,
  type Experience, type InsertExperience,
  type Education, type InsertEducation
} from "@shared/schema";
import { db } from "./db";
import { desc } from "drizzle-orm";

export interface IStorage {
  // Messages
  createMessage(message: InsertMessage): Promise<Message>;
  getMessages(): Promise<Message[]>;

  // Projects
  createProject(project: InsertProject): Promise<Project>;
  getProjects(): Promise<Project[]>;

  // Skills
  createSkill(skill: InsertSkill): Promise<Skill>;
  getSkills(): Promise<Skill[]>;

  // Experiences
  createExperience(experience: InsertExperience): Promise<Experience>;
  getExperiences(): Promise<Experience[]>;

  // Education
  createEducation(education: InsertEducation): Promise<Education>;
  getEducation(): Promise<Education[]>;
}

export class DatabaseStorage implements IStorage {
  // Messages
  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  async getMessages(): Promise<Message[]> {
    return await db.select().from(messages).orderBy(desc(messages.createdAt));
  }

  // Projects
  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.createdAt));
  }

  // Skills
  async createSkill(skill: InsertSkill): Promise<Skill> {
    const [newSkill] = await db.insert(skills).values(skill).returning();
    return newSkill;
  }

  async getSkills(): Promise<Skill[]> {
    return await db.select().from(skills).orderBy(desc(skills.createdAt));
  }

  // Experiences
  async createExperience(experience: InsertExperience): Promise<Experience> {
    const [newExperience] = await db.insert(experiences).values(experience).returning();
    return newExperience;
  }

  async getExperiences(): Promise<Experience[]> {
    return await db.select().from(experiences).orderBy(experiences.order);
  }

  // Education
  async createEducation(educationData: InsertEducation): Promise<Education> {
    const [newEducation] = await db.insert(education).values(educationData).returning();
    return newEducation;
  }

  async getEducation(): Promise<Education[]> {
    return await db.select().from(education).orderBy(education.order);
  }
}

export const storage = new DatabaseStorage();