import { useCallback } from 'react';

export function useSmoothScroll() {
  return useCallback((e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const href = e.currentTarget.getAttribute('href');
    
    if (!href?.startsWith('#')) return;
    
    const element = document.querySelector(href);
    if (!element) return;

    element.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });

    // Update URL without scroll
    window.history.pushState({}, '', href);
  }, []);
}
