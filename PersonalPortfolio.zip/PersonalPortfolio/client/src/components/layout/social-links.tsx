import { SiGithub, SiLinkedin } from "react-icons/si";

const socialLinks = [
  {
    icon: SiGithub,
    href: "https://github.com",
    label: "GitHub",
  },
  {
    icon: SiLinkedin,
    href: "https://linkedin.com",
    label: "LinkedIn",
  },
];

export default function SocialLinks() {
  return (
    <div className="flex space-x-4">
      {socialLinks.map((link) => (
        <a
          key={link.label}
          href={link.href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-foreground/80 hover:text-primary transition-colors"
          aria-label={link.label}
        >
          <link.icon className="w-6 h-6" />
        </a>
      ))}
    </div>
  );
}