import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

export default function About() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  };

  return (
    <section id="about" className="py-20 bg-muted/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={containerVariants}
        >
          <motion.h2 
            className="text-3xl font-bold text-center mb-4"
            variants={itemVariants}
          >
            About Me
          </motion.h2>
          <motion.p 
            className="text-center text-foreground/80 max-w-2xl mx-auto mb-12"
            variants={itemVariants}
          >
            Where creativity meets technology
          </motion.p>

          <motion.div 
            className="mt-12 text-center"
            variants={itemVariants}
          >
            <Card className="max-w-3xl mx-auto overflow-hidden">
              <CardContent className="p-6">
                <div className="prose prose-sm sm:prose lg:prose-lg mx-auto">
                  <p className="text-foreground/80">
                    As a scriptwriter turned developer, I bring a unique perspective to every project. 
                    I understand that every line of code tells a story, just like every scene in a script 
                    serves a purpose. My background in creative writing enables me to create intuitive user 
                    experiences that engage and captivate, while my technical skills ensure those experiences 
                    are built on a solid foundation.
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}