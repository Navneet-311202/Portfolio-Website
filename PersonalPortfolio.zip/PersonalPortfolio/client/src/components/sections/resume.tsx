import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileDown } from "lucide-react";

const resumeData = {
  experience: [
    {
      title: "Senior Scriptwriter",
      company: "Creative Studios",
      period: "2020 - Present",
      description: "Lead scriptwriter for various digital media projects, collaborating with production teams and clients to create engaging narratives.",
    },
    {
      title: "Content Developer",
      company: "Digital Media Agency",
      period: "2018 - 2020",
      description: "Created compelling content strategies and narratives for digital platforms while learning web development.",
    },
  ],
  education: [
    {
      degree: "Master of Fine Arts in Creative Writing",
      school: "University of Arts",
      year: "2018",
    },
    {
      degree: "Bachelor of Arts in English Literature",
      school: "State University",
      year: "2016",
    },
  ],
  skills: [
    "Creative Writing",
    "Screenplay Writing",
    "Story Development",
    "Web Development",
    "React",
    "JavaScript/TypeScript",
  ],
};

export default function Resume() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section id="resume" className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={containerVariants}
        >
          <motion.div variants={itemVariants}>
            <h2 className="text-3xl font-bold text-center mb-4">Resume</h2>
            <p className="text-center text-foreground/80 max-w-2xl mx-auto mb-12">
              My professional journey in storytelling and development
            </p>
          </motion.div>

          <div className="grid gap-8 md:grid-cols-2">
            <motion.div variants={itemVariants}>
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-semibold mb-6">Experience</h3>
                  <div className="space-y-6">
                    {resumeData.experience.map((exp, index) => (
                      <motion.div
                        key={index}
                        variants={itemVariants}
                        className="border-l-2 border-primary pl-4"
                      >
                        <h4 className="text-xl font-medium">{exp.title}</h4>
                        <p className="text-primary">{exp.company}</p>
                        <p className="text-sm text-foreground/60">{exp.period}</p>
                        <p className="mt-2 text-foreground/80">
                          {exp.description}
                        </p>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants} className="space-y-8">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-semibold mb-6">Education</h3>
                  <div className="space-y-4">
                    {resumeData.education.map((edu, index) => (
                      <motion.div key={index} variants={itemVariants}>
                        <h4 className="text-xl font-medium">{edu.degree}</h4>
                        <p className="text-primary">{edu.school}</p>
                        <p className="text-sm text-foreground/60">{edu.year}</p>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-semibold mb-6">Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {resumeData.skills.map((skill, index) => (
                      <motion.span
                        key={index}
                        variants={itemVariants}
                        className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm"
                      >
                        {skill}
                      </motion.span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <motion.div variants={itemVariants} className="mt-8 text-center">
            <Button variant="outline" size="lg">
              <FileDown className="mr-2 h-4 w-4" />
              Download Full Resume
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
